# 全局技能注册表（主技能索引）v1.3

> 本文件是主技能索引，仅列所有已注册的主 Skill 及其基本信息。
> 原子技能详情请查看 `.claude/skills/orchestrator/atomic_skills_register.md`。

version: 1.8
说明：
1. 本索引供 Reasoner（orchestrator）读取，用于意图匹配
2. 原子技能详情在 `atomic_skills_register.md` 中，按主技能分组
3. 新增/删除/修改主技能时，同步更新本索引和 `atomic_skills_register.md`
4. 未注册的主技能不允许被 orchestrator 选择和执行

---

## 主技能索引

```yaml
- name: orchestrator
  desc: 统一任务编排入口 — 意图识别、Skill 匹配、任务生成、执行控制、结果校验、任务归档
  path: .claude/skills/orchestrator/SKILL.md
  core_ability: 意图识别、上下文感知、多 Skill 组合、DAG 任务生成、断点恢复、结果校验和归档
  match_keywords: [所有意图]
  status: 启用
  is_reasoner: true
  note: 统一执行轻量和完整任务编排流程

- name: code-generator
  desc: 根据需求文档或需求描述自动生成符合项目规范的代码，支持多种输入形式并自动适配项目技术栈
  path: .claude/skills/code-generator/SKILL.md
  core_ability: 需求理解、技术栈检测、代码结构设计、代码生成、模块整合、代码验证、文档更新
  match_keywords: 根据需求写代码, 实现这个功能, 生成代码, 写一个函数, 实现这个模块, 按照需求文档开发, 帮我实现
  status: 启用

- name: code-optimizer
  desc: 系统化地优化代码，基于代码质量分析识别改进点，提供可执行的优化方案，并应用修改以提升代码质量、性能和可维护性（v2.0，整合性能优化+冗余检测）
  path: .claude/skills/code-optimizer/SKILL.md
  core_ability: 静态代码质量分析、代码模式识别、性能分析、冗余检测、优化建议、自动化代码重构、优化验证、文档维护
  match_keywords: 优化代码, 重构代码, 更好的实现方式, 性能优化, 提高代码质量, 改进这个函数, 简化这段代码, 消除代码重复, 检查代码冗余, 检测重复代码, 找出死代码, 清理未使用代码, 冗余导入, 代码重复率
  status: 启用

- name: code-style-generator
  desc: 自动检测项目代码规范，生成个人代码习惯文档 CODE_STYLE.md
  path: .claude/skills/code-style-generator/SKILL.md
  core_ability: 检测配置文件、扫描代码推断规范、生成代码风格文档
  match_keywords: 生成代码习惯文档, 创建代码风格规范, 生成CODE_STYLE, 检测代码规范, 代码规范文档
  status: 启用

- name: cheers
  desc: 首次将 Claude Code Skills 引入项目时的初始化 skill。依次执行：检测/生成 CLAUDE.md → 扫描项目信息 → 生成项目代码风格 → 生成个人代码习惯，最终在 CLAUDE.md 中写入代码生成优先级说明（个人风格优先，项目规范兜底）。支持多 Skill 协同执行。
  path: .claude/skills/cheers/SKILL.md
  core_ability: CLAUDE.md 检测/生成、项目信息扫描、代码风格生成、个人习惯收集、CLAUDE.md 合并更新
  match_keywords: 初始化项目, 设置项目, 首次配置, 项目引导, cheers, 首次使用, 欢迎使用
  status: 启用

- name: bug-solver
  desc: 系统化地解决应用程序中的bug，通过7个原子Skill协同工作，从问题识别到修复验证，完整记录和追溯整个debug过程
  path: .claude/skills/bug-solver/SKILL.md
  core_ability: 问题分类(Bug Triage)、问题识别、代码分析、根因定位、安全修复、修复验证、测试建议
  match_keywords: 解决bug, 修复错误, 调试问题, 定位问题, debug, bug修复, 错误分析
  status: 启用

- name: personal-code-habits-generator
  desc: 从人的角度主动询问用户，生成个人代码习惯文档 CODE_STYLE_PERSONAL.md。与 code-style-generator（从代码推断）不同，本 skill 通过主动询问用户来收集个人开发习惯，适合新环境或系统化整理个人习惯。
  path: .claude/skills/personal-code-habits-generator/SKILL.md
  core_ability: 对话式习惯收集、分批次提问、CODE_STYLE_PERSONAL.md 生成、用户确认与补充
  match_keywords: 生成我的代码习惯, 生成个人代码规范, 我习惯怎么写代码, 记录我的开发习惯, 我的编码偏好, 生成代码风格, 个人代码习惯
  status: 启用

- name: scan-object-info
  desc: 智能扫描并分析前端项目的各种技术信息（框架、UI库、状态管理、请求方案、配置文件、项目结构、路由方案、环境变量等）
  path: .claude/skills/scan-object-info/SKILL.md
  core_ability: 智能意图识别、精准技能选择、依赖关系分析、结构化输出、错误处理、技术栈全面扫描
  match_keywords: 扫描项目, 分析项目, 项目信息, 技术栈, 项目结构, 配置文件, 依赖分析, 框架识别, UI库, 状态管理, 请求方案, 路由方案, 环境变量
  status: 启用

- name: requirement-generator
  desc: 将用户自然语言需求转化为标准化、可执行的机器需求文档（requirements.json），支持多模态输入，依赖外部项目上下文
  path: .claude/skills/requirement-generator/SKILL.md
  core_ability: 多模态需求输入、需求模块化分解、7种通用前端流程识别、REST API规格设计、测试用例生成、需求质量评估
  match_keywords: 需求分析, 需求文档, 功能规格, 将需求标准化, 需求转化为规格
  status: 启用

- name: performance-optimizer
  desc: "[已合并至 code-optimizer v2.0] 专注于前端性能优化，通过性能分析、基准测试生成和优化验证，系统化地提升应用性能（首屏加载、渲染性能、资源体积等）。功能已整合进 code-optimizer，无需单独使用。"
  path: .claude/skills/code-optimizer/SKILL.md
  core_ability: 性能数据分析、基准测试生成、优化方案设计、优化方案应用、优化效果验证
  match_keywords: 性能优化, 首屏加载优化, 渲染性能, 资源体积, 加载速度优化, Web Vitals, Lighthouse
  status: 已合并

- name: security-scanner
  desc: 系统化地扫描前端项目中的安全漏洞，包括XSS、CSRF、依赖漏洞、敏感信息泄露等，提供修复建议
  path: .claude/skills/security-scanner/SKILL.md
  core_ability: 漏洞扫描、依赖安全检查、敏感信息检测、安全报告生成、修复建议
  match_keywords: 安全扫描, 安全漏洞, XSS, CSRF, 依赖安全, 敏感信息检测, 安全审计
  status: 启用

- name: test-generator
  desc: 根据现有代码或需求自动生成测试用例，覆盖单元测试、集成测试和E2E测试，支持主流测试框架（Vitest、Jest、Playwright）
  path: .claude/skills/test-generator/SKILL.md
  core_ability: 测试用例设计、测试代码生成、测试框架适配、测试覆盖分析
  match_keywords: 生成测试, 测试用例, 单元测试, 集成测试, E2E测试, 添加测试, 测试覆盖
  status: 启用

- name: skill-analyzer
  desc: 系统化地解读和分析任意 Skill 的 SKILL.md 文件，生成结构化的分析报告（功能说明、执行流程、输出结果、架构设计、思维方式、优缺点分析、使用建议）。当用户要求"解读"、"分析"、"理解"某个 Skill 时触发。
  path: .claude/skills/skill-analyzer/SKILL.md
  core_ability: 8维度 Skill 分析、功能解读、执行流程解析、架构设计推断、优缺点评估、文档生成
  match_keywords: 解读Skill, 分析Skill, 理解Skill, 解读架构, 分析设计, Skill分析报告, 解读文档
  status: 启用

- name: doc-generator
  desc: 自动生成代码文档，包括API文档、README、组件文档、变更日志等，支持多种格式（Markdown、API文档、TypeDoc、JSDoc）
  path: .claude/skills/doc-generator/SKILL.md
  core_ability: API文档生成、README生成、组件文档生成、变更日志生成、文档格式转换
  match_keywords: 生成文档, API文档, README, 组件文档, 变更日志, 文档更新, 生成注释
  status: 启用

- name: git-assistant
  desc: 智能 Git 操作助手，支持 commit 生成、分支管理、历史分析、冲突解决、Stash 操作、版本管理、提交规范检查
  path: .claude/skills/git-assistant/SKILL.md
  core_ability: 意图识别与路由、Git 命令生成
  match_keywords: 提交, commit, 分支, branch, 冲突, conflict, stash, 历史, history, blame, tag, 版本, merge, rebase, git操作
  status: 启用

- name: deploy-helper
  desc: 辅助部署操作，支持Docker配置、CI/CD流水线生成、环境配置、部署脚本生成，适配主流平台（Vercel、Netlify、Docker）
  path: .claude/skills/deploy-helper/SKILL.md
  core_ability: Docker配置生成、CI/CD流水线生成、环境配置、部署脚本生成、部署验证
  match_keywords: 部署, Docker, CI/CD, 环境配置, 部署脚本, Vercel, Netlify, 自动化部署
  status: 启用

- name: code-structure-analyzer
  desc: 读取项目中某个页面、业务模块或流程的代码，分析整体流程、逻辑、关键节点、重要变量和依赖关系，在同目录下生成以分析对象命名的 md 文档
  path: .claude/skills/code-structure-analyzer/SKILL.md
  core_ability: 代码结构扫描、流程逻辑分析、关键节点识别、变量/依赖提取、依赖关系图生成、文档自动生成
  match_keywords: 分析代码结构, 代码结构分析, 生成流程图, 流程分析, 提取依赖关系, 依赖分析, 关键节点识别, 节点分析, 变量提取, 状态变量分析
  status: 启用

- name: product-designer
  desc: 将用户简单的需求描述扩展为完整的产品模块设计方案，替代产品经理工作。75%围绕需求本身，25%合理发散，不确定部分必须向用户提问而非臆想（v1.0 初始版）
  path: .claude/skills/product-designer/SKILL.md
  core_ability: 需求澄清与范围确认、角色矩阵设计、功能树设计、数据实体设计、API接口设计、验收条件设计、非功能需求识别、产品模块文档输出
  match_keywords: 设计产品模块, 扩展需求, 产品功能设计, 用户故事, 功能规格, 产品模块, 模块设计, 功能点设计, 需求扩展, 产品方案
  status: 启用

- name: project-cloud-map
  desc: 读取整个项目当前代码快照，自动识别 Web/全栈/后端/CLI/库类型，按页面或入口、数据流和交互逻辑拆分模块，输出 Markdown + Mermaid 项目云图；代码变更前必须列候选方案并等待确认
  path: .claude/skills/project-cloud-map/SKILL.md
  core_ability: 全项目快照读取、项目类型识别、页面/入口拆分、模块与数据流分析、交互链路分析、Markdown/Mermaid 云图输出、变更前确认
  match_keywords: 项目云图, 项目地图, 系统全貌, 架构鸟瞰, 页面关系, 模块关系, 数据流梳理, 项目结构图, 代码全景
  status: 启用

- name: project-planner
  desc: 基于迭代周期规划项目目标，生成每日工作内容与项目进度追踪，支持多项目分组管理和超期预警，具备历史速度学习能力动态调整估算精度
  path: .claude/skills/project-planner/SKILL.md
  core_ability: 迭代周期规划、目标→任务双向拆解、每日工作生成、进度追踪、超期预警、历史速度学习、动态估算调整、多项目分组、日报/周报/仪表盘输出
  match_keywords: 项目规划, 迭代计划, 每周目标, 每日工作, 任务规划, 项目进度, 进度追踪, 超期预警, 里程碑, 甘特图, 任务分配, sprint计划, 每日计划, 工作内容, 多项目
  status: 启用
```

---

## 主技能统计（v1.9）

| 类别 | 数量 |
|------|------|
| 总主技能数 | 19 |
| Reasoner（调度器） | 1（orchestrator）|
| 功能主技能 | 18 |

---

## 维护说明

- 添加新主技能 → 更新本索引 + 在 `atomic_skills_register.md` 添加原子技能
- 调整匹配关键词 → 修改本索引对应条目
- 原子技能详情 → 查看 `atomic_skills_register.md`

---

**版本**: 1.9
**最后更新**: 2026-06-18
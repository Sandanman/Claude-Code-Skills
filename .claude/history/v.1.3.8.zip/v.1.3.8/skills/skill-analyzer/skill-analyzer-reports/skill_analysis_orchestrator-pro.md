# Orchestrator Pro — 智能调度总控 解读报告

> 解读日期：2026-06-05（目标 Skill 版本日期，基于 SKILL.md 版本历史 v1.6）
> Skill 版本：v1.6
> 分析者：Claude Code Skill Analyzer
> 报告生成时间：2026-06-15 11:29:00

---

## 1. 功能说明

### 1.1 核心功能

Orchestrator Pro 是整个 Claude Code Skills 项目的**唯一调度入口**，基于华为韬定律（τ-Law）构建，以 τ（时间常数）作为统一性能指标，对所有用户任务进行复杂度分流、意图识别、主 skill 匹配、子任务生成、并行执行控制、结果校验和归档的全链路自动化调度。

### 1.2 解决问题

- **无调度器时代的问题**：用户不知道该用哪个 skill，所有请求散乱无序
- **粗粒度调度的问题**：简单任务被过度工程化，τ 资源浪费
- **缺乏性能感知的问题**：执行过程无预算控制，容易无限消耗 token 和时间
- **结果不可追溯的问题**：任务完成后缺少固化文档记录和历史复用机制

### 1.3 触发条件

用户输入任意任务描述（通过 `/orchestrator-pro` 或 `/orchestrator` 触发），内部自动完成复杂度评分路由，无须用户手动选择。

### 1.4 核心能力列表

- **复杂度分流**：自动判断 complexity < 4 降级轻量路径，≥ 4 走 τ 优化路径
- **意图识别**：LLM 分析 + 复杂度评分，提取 domain/action/intent
- **主 skill 匹配**：三分支逻辑（无匹配/单匹配/多匹配），自主执行兜底
- **Task Folding**：τ 不足时自动折叠可合并的任务链路
- **Pattern Mining**：历史相似度 ≥ 0.6 复用成熟子步骤，τ 折扣最高 70%
- **Skill Stacking**：通过 task_skill.md 共享上下文，上下游 skill 直读
- **Co-Design**：Model × Rules × Skills 三层贡献度显式化追踪
- **三指标度量**：τ 为主标准（驱动决策）+ Token/Duration 为辅助标准（观测/告警）
- **τ 分解报告**：步骤 8 输出端到端 τ/Token/Duration 三维效率分析

---

## 2. 执行流程

### 2.1 执行管道

```
用户输入
    ↓
[步骤1] 意图识别 + 复杂度评分 + 复杂度分流（<4 降级轻量路径）
    ↓ (complexity ≥ 4)
[步骤2] 历史检索（双轨并行：历史相似度 + Pattern Mining）
    ↓
[步骤3] 主 skill 匹配（三分支：无匹配/单匹配/多匹配）
    ↓ 读取匹配 skill 的 SKILL.md
[步骤4] 任务生成（DAG构建 + Task Folding 折叠）
    ↓ 实例化 task_skill.md
[步骤5] 执行流程控制（三指标并行监控 + 紧急折叠）
    ↓
[步骤6] 任务恢复（τ 元数据恢复）
    ↓
[步骤7] 结果校验（三指标效率评分 + 异常标记）
    ↓
[步骤8] 结果输出（三指标分解报告）
    ↓
[步骤9] 任务归档（Pattern 存储 + 固化文档路径记录）
    ↓
【end】
```

轻量路径（complexity < 4）：显式读取并执行 `orchestrator/SKILL.md`，不走 τ 增强逻辑。

### 2.2 原子技能依赖关系

| 原子技能 | 路径 | 依赖 | 角色 | 可折叠 |
|---------|------|------|------|--------|
| intent-recognition | atomic-skills/ | 无 | 核心 | 否 |
| skill-matcher | atomic-skills/ | intent-recognition | 核心 | 否 |
| task-generator | atomic-skills/ | skill-matcher | 核心 | 是（Task Folding） |
| execution-controller | atomic-skills/ | task-generator | 核心 | 是（紧急折叠） |
| result-validator | atomic-skills/ | execution-controller | 核心 | 是（Task Folding） |
| task-archiver | atomic-skills/ | result-validator | 核心 | 是（Task Folding） |
| pattern-miner | atomic-skills/ | 无（步骤2并行） | 增强 | 否 |
| tau-controller | atomic-skills/ | 全流程嵌入 | 元控制 | 是（监控/折叠） |

### 2.3 τ 控制机制

**三档预算**：
| 复杂度 | τ 预算 | Token 预算 | Duration 预算 |
|--------|--------|-----------|-------------|
| simple | 5,000 | 40,000 | 15,000ms |
| moderate | 15,000 | 80,000 | 30,000ms |
| complex | 50,000 | 200,000 | 80,000ms |

**预算分配**（τ 权重）：intent=10%, match=15%, plan=5%, exec=60%, validate=5%, archive=5%

**τ 预警规则**：80% 警告 / 95% 严重 / 100% 终止

**Task Folding 触发条件**：τ_remaining < 30% 且 depth > 3，最多折叠 2 次

**Token/时间异常阈值**（辅助，告警不阻断）：
- token_pct < 20%：警告；< 5%：严重
- ms/token > 10ms：延迟异常警告；> 20ms：严重延迟
- τ > 50% 但 token/dur < 30%：综合异常提示

---

## 3. 最终输出结果

| 输出类型 | 输出位置 | 格式 | 说明 |
|---------|---------|------|------|
| task_skill.md（执行中） | tasks/current/ | Markdown | 任务状态实时写入，含三指标元数据 |
| task_skill.md（归档） | tasks/history/YYYY-MM/ | Markdown | 含固化文档路径记录 |
| 月度任务索引 | tasks/history/YYYY-MM/月度任务索引.md | Markdown | 归档任务索引 |
| 三指标分解报告 | 对话输出 + task_skill.md | Markdown | τ/Token/Duration 三维分解 |
| 异常标记 | 对话输出 + task_skill.md | Markdown | token_drift / time_drift / latency_ratio |
| Pattern 模式文件 | skills/patterns/{category}/ | Markdown | 任务完成后自动存入模式库 |

---

## 4. 架构设计与思维方式

### 4.1 架构模式

- **管道模式（Pipe-and-Filter）**：9 步串行管道，每步输出作为下一步输入
- **分层模式（Layered）**：τ 元控制层（tau-controller）独立于业务逻辑层
- **插件模式（Plugin）**：原子技能可独立替换，通过 SKILL.md 注册
- **路由模式（Router）**：复杂度分流、skill 匹配三分支、自主执行兜底
- **τ 增强模式**：时间缩微驱动决策，非堆参数空间

### 4.2 设计原则

- **单一职责**：每个原子技能只负责一个职责（识别/匹配/生成/执行/校验/归档）
- **可复用性**：Pattern Mining 使成熟任务模式 τ 折扣 70%，避免重复规划
- **可测试性**：步骤解耦（Task Folding、Co-Design 贡献度可独立验证）
- **渐进式披露**：复杂度低时走轻量路径，避免信息过载
- **资源感知**：τ 预算驱动决策，提前感知资源瓶颈
- **韧性兜底**：无匹配时自主执行 + 清晰的用户引导

### 4.3 τ 增强设计

| 技术 | 实现位置 | 作用 |
|------|---------|------|
| K1 Task Folding | 步骤 4（DAG构建后）+ 步骤 5（执行中紧急折叠）| 节省约 30% τ 消耗 |
| K2 Skill Stacking | 步骤 3（SKILL.md 上下文预加载）+ 步骤 5（命中追踪）| 命中率 < 50% 警告 |
| K3 Co-Design | 各步骤显式记录 Model/Rules/Skills 贡献度 | 透明度 + 效率分析 |
| K4 Pattern Mining | 步骤 2（双轨并行）+ 步骤 9（模式存储）| 成熟模式 τ 折扣 70% |

### 4.4 思维方式推断

1. **时间即资源**：将时间量化为 τ，用 τ 而非堆参数来提升效率——这是华为韬定律的核心，也是整个架构的根本哲学
2. **分层抽象**：τ 是主标准（决策驱动），Token/Time 是辅助标准（观测告警），职责清晰不混淆
3. **渐进增强**：轻量路径完整继承旧版行为，τ 增强叠加在轻量路径之上，不破坏兼容性
4. **自举设计**：模式库自我积累，随着使用越来越高效（成熟模式 τ 折扣 70%）
5. **显式优于隐式**：Co-Design 将 Model/Rules/Skills 三方贡献度显式记录，便于审计和优化

---

## 5. 这样做的好处

1. **统一入口消除散乱**：所有任务通过一个入口，skill 匹配透明化，用户无认知负担
2. **复杂度自适应**：简单任务不走复杂流程，节省约 60-70% τ 消耗（轻量路径无 Task Folding/Pattern Mining 开销）
3. **τ 预算防止无限消耗**：100% 终止机制 + 紧急折叠，保证任务不会因为资源耗尽而卡死
4. **Pattern 复用加速成熟领域**：成熟领域（≥5次）τ 折扣 70%，常用任务越来越快
5. **Skill Stacking 避免重复读取**：上游 skill 输出写入共享上下文，下游 skill 直读，省去重复 I/O
6. **三指标并行监控**：τ 驱动决策，Token/Time 提供独立告警视角，提前发现异常
7. **固化文档路径永久可追溯**：归档后固化文档路径记录在 task_skill.md 中，后续任务可引用
8. **轻量路径完全兼容旧版**：orchestrator/SKILL.md 作为 orchestrator-pro 的执行模块，0 破坏性升级

---

## 6. 优缺点分析

### 6.1 优点

- **架构完整性高**：从意图识别到归档，9 步覆盖完整任务生命周期
- **τ 设计理念先进**：用时间缩微而非模型堆叠，符合资源受限场景
- **可进化**：Pattern 库自我积累，系统越用越快（mature 模式 70% 折扣）
- **容错机制完善**：无匹配时自主执行兜底 + 清晰的 user_action_required 提示
- **透明度高**：Co-Design 贡献度显式化，便于理解每个步骤的决策来源
- **测试友好**：三指标元数据实时写入 task_skill.md，可事后回放分析

### 6.2 缺点/限制

- **复杂度阈值（4）依赖经验**：complexity_score 的计算逻辑可能不稳定，阈值 4 是经验值
- **Task Folding 折叠决策有误判风险**：τ_remaining < 30% 触发折叠，可能折叠了实际上需要执行的核心步骤
- **Pattern Mining 阈值 0.6 偏低**：可能复用不恰当的模式导致结果偏差
- **Skill Stacking 命中率依赖正确写入**：如果上游 skill 未按规范写入共享上下文，命中率下降
- **自主执行兜底逻辑较简单**：仅处理高置信度（≥0.7）的简单 domain-action 组合，复杂任务仍需 skill
- **三指标并行报告复杂度高**：步骤 8 输出内容量大，非专业用户可能难以理解
- **跨项目部署（v1.5 修复）仍有潜在问题**：需要显式读取匹配 skill 的 SKILL.md，如果路径变更可能失效

### 6.3 适用场景

- 复杂多模块开发任务（complexity ≥ 4）
- 需要性能分析和优化的持续使用场景（Pattern 积累越来越多）
- 跨多 skill 协调的复合任务（如 bug-solver → scan-object-info → code-generator 链路）
- 需要固化文档（CODE_STYLE、安全报告等）并长期维护的项目

### 6.4 不适用场景

- 一次性简单任务（直接用对应 skill 更高效，如 `/code-generator "写一个函数"`）
- 实时性要求极高（τ 初始化/折叠决策本身有开销）
- 无历史积累的新项目（Pattern Mining 初期无模式可复用，优势无法发挥）

---

## 7. 使用建议

### 7.1 最佳实践

1. **保持 task_skill.md 规范写入**：每个原子 skill 完成后必须写入共享上下文，这是 Skill Stacking 命中率的基础
2. **利用 Pattern 积累**：成熟项目定期查看 `.claude/skills/patterns/`，理解已有模式的适用条件
3. **关注异常标记**：三指标分解报告中的异常标记（token_drift、time_drift、latency_ratio）值得定期复盘
4. **固化文档及时迁移**：步骤 9 归档时提示的"可固化文档"应尽快移至项目目录，避免丢失
5. **复杂度判断参考**：当任务被错误路由到轻量路径时（如多模块开发被误判），可用更详细的描述提升 complexity_score

### 7.2 注意事项

- 步骤 3 匹配到主 skill 后**必须读取该 skill 的 SKILL.md**（v1.5 修复的跨项目部署问题）
- Task Folding 折叠后必须重新分配 τ 预算，否则后续步骤会持续超支
- Pattern 模式存储条件：validation_report.all_passed 且 deviation < 0.2，不满足条件不存储
- 原子技能中 `is_core: true` 或 `user_required: true` 的不可被紧急折叠
- 三指标中 Token 和 Duration **仅用于观测/告警，不驱动决策**（不能因为 Token 不足而终止任务）

### 7.3 扩展建议

1. **可配置化复杂度阈值**：将硬编码的 4 改为可配置参数，适应不同项目需求
2. **Pattern 可视化**：增加 `.claude/skills/patterns/` 的查询接口，查看已有模式分布
3. **Co-Design 仪表盘**：将各步骤的 Model/Rules/Skills 贡献度可视化，便于理解系统决策来源
4. **Skill Stacking 命中率告警**：当命中率持续 < 30%，主动建议检查上游 skill 输出规范
5. **历史任务回放**：基于 task_skill.md 归档文件，支持非执行回放和离线分析

---

## 8. 与 orchestrator（轻量版）的关系总结

| 维度 | orchestrator（轻量）| orchestrator-pro（τ 优化）|
|------|-------------------|------------------------|
| 触发条件 | complexity < 4 | complexity ≥ 4 |
| 执行逻辑 | 9 步基础流程 | 9 步 + τ 增强 |
| 入口 | 仅被 orchestrator-pro 显式调用 | **唯一真实入口** |
| 原子技能 | atomic-skills/ 已清空，仅 SKILL.md | 8 个原子技能，完整功能 |
| Token 追踪 | 有 | 有（且扩展为三指标）|
| Task Folding | 无 | 有（步骤 4 + 5）|
| Pattern Mining | 无 | 有（步骤 2 + 9）|
| Skill Stacking | 基础 | 命中率追踪，<50% 警告 |
| Co-Design | 无 | 各步骤显式记录 |
| τ 报告 | 无 | 步骤 8 三指标分解报告 |

---

*报告生成时间：2026-06-15 11:29:00（动态时间戳，不硬编码）*

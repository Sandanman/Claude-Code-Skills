# 缺失技能清单（Reasoner记录）v1.2

## 说明
本清单记录 Reasoner 无法匹配到符合需求的主skill/原子skill 的场景，用于后续技能补充，不影响当前流程执行。

| 记录时间 | 用户意图（核心） | 所需技能类型 | 缺失原因 | 补充建议 | 处理状态 |
|----------|------------------|--------------|----------|----------|----------|
| 2026-04-08 13:30:00 | 分析项目结构和基本信息 | 主skill: analyze_project | 无匹配技能 | 新增 analyze_project 主skill | 未处理 |
| 2026-05-21 20:00:00 | 自动生成测试用例 | 主skill: test-generator | 新技能，已添加至v1.2 | 新增 test-generator 主skill | 已处理 |
| 2026-05-21 20:00:00 | 性能优化和基准测试 | 主skill: performance-optimizer | 新技能，已添加至v1.2 | 新增 performance-optimizer 主skill | 已处理 |
| 2026-05-21 20:00:00 | 安全漏洞扫描 | 主skill: security-scanner | 新技能，已添加至v1.2 | 新增 security-scanner 主skill | 已处理 |
| 2026-05-21 20:00:00 | 文档自动生成 | 主skill: doc-generator | 新技能，已添加至v1.2 | 新增 doc-generator 主skill | 已处理 |

## 补充建议

### 新增技能（v1.2 规划）
以下技能已在 v1.2 中实现，位于 `.claude/skills/` 目录下：
- `test-generator`: 自动生成测试用例
- `performance-optimizer`: 性能优化和基准测试
- `security-scanner`: 安全漏洞扫描
- `doc-generator`: 文档自动生成
- `git-helper`: Git操作辅助
- `deploy-helper`: 部署辅助

### 待评估技能
以下技能方向待评估是否需要实现：
- `data-migration`: 数据迁移辅助
- `api-mock-generator`: API Mock生成器
- `i18n-helper`: 国际化辅助工具
- `accessibility-checker`: 无障碍访问检查

---

**版本**: 1.2
**最后更新**: 2026-05-21
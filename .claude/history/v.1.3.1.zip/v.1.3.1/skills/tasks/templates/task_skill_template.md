# 任务基础信息
任务ID：{自动生成，格式：YYYYMMDDHHMMSS_随机6位数字}
用户意图：{Reasoner传入的明确意图}
最终目标：{Reasoner与主skill确认的核心目标}
归属主skill：{所选主skill名称}
创建时间：{YYYY-MM-DD HH:MM:SS}
当前状态：待执行/执行中/暂停/已完成/失败 （必须使用上述状态）
归档路径：未归档（执行完毕后自动更新为tasks/history/YYYY-MM/）

# 子任务（原子skill）列表
| 原子skill名称 | 所属主skill | 状态（待执行/执行中/已完成/失败） | 依赖子任务（无则填“无”） | 重试次数（0-3） | 执行日志 | 完成标准 |
|--------------|-------------|-----------------------------------|--------------------------|----------------|----------|----------|
| {原子skill1} | {对应主skill} | 待执行                            | {依赖的原子skill名称，无则填“无”} | 0              |          | {该原子skill的完成标准} |
| {原子skill2} | {对应主skill} | 待执行                            | {依赖的原子skill名称，无则填“无”} | 0              |          | {该原子skill的完成标准} |
| ...          | ...         | ...                               | ...                      | ...            | ...      | ...      |

# 主skill完成标准
{主skill与Reasoner同步确认的主skill完成标准，逐条列出}
1.  {标准1}
2.  {标准2}
...

# 执行日志（实时更新）
## 系统日志（Reasoner写入）
{YYYY-MM-DD HH:MM:SS}：任务创建，Reasoner与主skill确认原子skill执行顺序
{YYYY-MM-DD HH:MM:SS}：开始执行原子skill[{原子skill名称}]
{YYYY-MM-DD HH:MM:SS}：原子skill[{原子skill名称}]执行{成功/失败}，重试次数{X}
{YYYY-MM-DD HH:MM:SS}：反思校验，{符合目标/偏差XX，触发反思重规划}
...

## 错误日志（Reasoner/主skill写入）
{YYYY-MM-DD HH:MM:SS}：原子skill[{原子skill名称}]执行失败，原因：{具体原因}，已记录，准备重试
{YYYY-MM-DD HH:MM:SS}：反思重规划，调整原子skill执行顺序为：{调整后顺序}
...

# 最终结果汇总
{所有原子skill执行完毕后，主skill汇总结果，Reasoner校验后填写}
结果内容：{汇总结果}
是否符合目标：{是/否}
偏差值：{具体数值，如0.1}
反思日志：{关键问题、优化方向，无则填“无”}

# 归档说明
归档时间：{执行完毕后自动填写YYYY-MM-DD HH:MM:SS}
归档路径：{tasks/history/YYYY-MM/task_skill_{任务ID}.md}
是否可固化：{是/否，提示用户手动迁移至项目目录}
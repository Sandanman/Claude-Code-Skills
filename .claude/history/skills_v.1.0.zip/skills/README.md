# Skills System v1.0

基于意图驱动的多层级 Skill 编排系统，通过 Reasoner 调度器实现复杂任务的自主分解与执行。

## 架构概览

```
skills_v.1.0/
├── orchestrator/          # Reasoner 调度器（核心）
│   ├── SKILL.md           # 调度器主定义
│   ├── skills_register.md # 已注册主 skill 列表
│   ├── missing_skills.md  # 待完善 skill 列表
│   └── ...
├── bug-solver/            # 主 skill：Bug 修复
├── code-generator/        # 主 skill：代码生成
├── code-optimizer/       # 主 skill：代码优化
├── code-redundancy-checker/  # 主 skill：冗余检查
├── code-style-generator/  # 主 skill：代码风格生成
├── requirement-generator/ # 主 skill：需求生成
├── scan-object-info/      # 主 skill：对象信息扫描
├── tasks/                 # 任务工作区
│   ├── current/           # 当前任务（task_skill.md）
│   ├── history/          # 历史任务归档（YYYY-MM/）
│   └── templates/        # 任务模版
└── skill-design.md       # 设计思路文档
```

## 核心组件

### Orchestrator（调度器）

Reasoner 调度器是整个系统的唯一入口和调度核心，负责：
- 解析用户意图，判断任务复杂度
- 匹配并调度主 skill
- 掌控执行流程，实时更新任务状态
- 任务完成后归档与输出

> 详情见 [orchestrator/SKILL.md](orchestrator/SKILL.md)

### 主 Skill（Main Skill）

每个主 skill 下包含：
- `SKILL.md` — 技能定义
- `atomic-skills/` — 原子技能目录（可复用的最小执行单元）

| 主 Skill | 职责 |
|---|---|
| `bug-solver` | Bug 分析、定位与修复 |
| `code-generator` | 依据需求生成代码 |
| `code-optimizer` | 性能与结构优化 |
| `code-redundancy-checker` | 代码冗余检测 |
| `code-style-generator` | 代码风格标准化 |
| `requirement-generator` | 需求分析与文档生成 |
| `scan-object-info` | 项目对象信息扫描 |

### Tasks（任务工作区）

- `current/task_skill.md` — 当前任务状态文件（固定名称），包含所有子任务状态、执行日志、完成标准
- `history/YYYY-MM/` — 按月归档历史任务
- `templates/` — 任务模版（task_skill_template.md、月度任务索引模版.md）

## 执行流程

1. **意图识别** — Orchestrator 解析用户输入，判断复杂度
2. **历史检索** — 在 history 中检索相似任务（Top 3~5）
3. **Skill 匹配** — 匹配主 skill，如有多个则由用户选择
4. **任务生成** — 主 skill 组合原子 skill，生成 task_skill.md 到 current/
5. **执行编排** — Orchestrator 按 task_skill.md 顺序执行原子 skill，实时更新状态
6. **断点恢复** — 可从 task_skill.md 中任意未完成步骤继续
7. **归档输出** — 任务完成后归档至 history/YYYY-MM/，输出结果文档

> 完整执行流程见 [skill-design.md](skill-design.md)

## 权限配置

所有文件操作权限已统一配置在 `settings.local.json` 中，路径使用 `$CLAUDE_PROJECT_DIR` 环境变量，可直接复制到任意项目使用，无需修改。

## 扩展新的主 Skill

1. 在 `skills_v.1.0/` 下创建主 skill 目录（命名规范：`kebab-case`）
2. 编写 `SKILL.md` 和 `atomic-skills/` 下的原子 skill
3. 在 `orchestrator/skills_register.md` 中注册新 skill
4. Orchestrator 将在下次执行时自动识别并参与调度

## 目录命名约定

- 所有路径使用 `$CLAUDE_PROJECT_DIR` 环境变量，适配任意项目
- 主 skill 目录名：`kebab-case`（如 `bug-solver`、`code-redundancy-checker`）
- 原子 skill 目录名：与目录名相同
- 任务归档命名：`task_YYYYMMDD_HHMMSS_*.md`
- 月度索引文件：`月度任务索引.md`